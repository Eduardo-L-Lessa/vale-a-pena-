export function calculateViability(value, km, min) {
  const valuePerKm = value / km;
  const valuePerMin = value / min;
  let result = "vermelho";
  if (valuePerKm > 2.0 && valuePerMin > 0.5) result = "verde";
  else if (valuePerKm >= 1.5 && valuePerKm <= 2.0) result = "amarelo";
  return { valuePerKm, valuePerMin, result };
}
import React, { useState } from "react";
import RideForm from "./components/RideForm";
import TrafficLight from "./components/TrafficLight";
import RideHistory from "./components/RideHistory";
import MapArea from "./components/MapArea";
import MessageButton from "./components/MessageButton";
import VoiceAlert from "./components/VoiceAlert";

function loadHistory() {
  return JSON.parse(localStorage.getItem("ride_history") || "[]");
}
function saveHistory(history) {
  localStorage.setItem("ride_history", JSON.stringify(history));
}

export default function App() {
  const [current, setCurrent] = useState(null);
  const [history, setHistory] = useState(loadHistory());

  function handleSubmit(data) {
    setCurrent(data);
    const newHistory = [data, ...history].slice(0, 50); // mantém últimos 50
    setHistory(newHistory);
    saveHistory(newHistory);
  }

  return (
    <div style={{ maxWidth: 500, margin: "0 auto", padding: 16 }}>
      <h2>Vale a Pena? 🚗💸</h2>
      <RideForm onSubmit={handleSubmit} />
      {current && (
        <>
          <TrafficLight result={current.result} />
          <VoiceAlert result={current.result} />
          <div>
            <strong>Valor por km:</strong> R$ {current.valuePerKm.toFixed(2)} <br />
            <strong>Valor por min:</strong> R$ {current.valuePerMin.toFixed(2)}
          </div>
        </>
      )}
      <RideHistory history={history} />
      <MapArea />
      <MessageButton />
    </div>
  );
}
import React from "react";

export default function TrafficLight({ result }) {
  const colors = {
    verde: "#27ae60",
    amarelo: "#f7b731",
    vermelho: "#eb2f06"
  };
  return (
    <div style={{
      width: 80,
      height: 80,
      borderRadius: "50%",
      background: colors[result],
      margin: "16px auto",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: "#fff",
      fontWeight: "bold",
      fontSize: 22
    }}>
      {result?.toUpperCase() || "?"}
    </div>
  );
}
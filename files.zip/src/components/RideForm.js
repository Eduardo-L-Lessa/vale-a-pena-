import React, { useState } from "react";
import { calculateViability } from "../utils/calculation";

export default function RideForm({ onSubmit }) {
  const [value, setValue] = useState("");
  const [km, setKm] = useState("");
  const [min, setMin] = useState("");

  function handleSubmit(e) {
    e.preventDefault();
    if (!value || !km || !min) return;
    const res = calculateViability(Number(value), Number(km), Number(min));
    onSubmit({
      value: Number(value),
      km: Number(km),
      min: Number(min),
      ...res,
      date: new Date().toISOString()
    });
    setValue(""); setKm(""); setMin("");
  }

  return (
    <form onSubmit={handleSubmit}>
      <input type="number" step="0.01" placeholder="Valor da corrida (R$)" value={value} onChange={e => setValue(e.target.value)} required />
      <input type="number" step="0.1" placeholder="Distância (km)" value={km} onChange={e => setKm(e.target.value)} required />
      <input type="number" step="1" placeholder="Tempo estimado (min)" value={min} onChange={e => setMin(e.target.value)} required />
      <button type="submit">Calcular</button>
    </form>
  );
}
import React from "react";

export default function VoiceAlert({ result }) {
  React.useEffect(() => {
    if (!result) return;
    const text = {
      verde: "Corrida boa!",
      amarelo: "Corrida média.",
      vermelho: "Corrida ruim."
    }[result];
    if ("speechSynthesis" in window && text) {
      const utter = new window.SpeechSynthesisUtterance(text);
      window.speechSynthesis.speak(utter);
    }
  }, [result]);
  return null;
}
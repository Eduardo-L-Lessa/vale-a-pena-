import React from "react";

const message = "Olá, estou a caminho. Em breve estarei no local. Qualquer dúvida, me chame aqui pelo app. Obrigado!";

export default function MessageButton() {
  function copyAndOpenWhatsapp() {
    navigator.clipboard.writeText(message);
    window.open("https://wa.me/?text=" + encodeURIComponent(message), "_blank");
  }
  return <button onClick={copyAndOpenWhatsapp}>Enviar mensagem ao passageiro</button>;
}
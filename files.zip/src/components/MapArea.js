import React, { useRef } from "react";

export default function MapArea() {
  const originRef = useRef();
  const destRef = useRef();
  const [iframeUrl, setIframeUrl] = React.useState("");

  function handleShowRoute(e) {
    e.preventDefault();
    const origin = encodeURIComponent(originRef.current.value);
    const dest = encodeURIComponent(destRef.current.value);
    // Use Google Maps Directions URL
    setIframeUrl(`https://www.google.com/maps/dir/?api=1&origin=${origin}&destination=${dest}`);
  }

  return (
    <div>
      <h3>Mapa de Origem e Destino</h3>
      <form onSubmit={handleShowRoute}>
        <input ref={originRef} type="text" placeholder="Endereço de Origem" required />
        <input ref={destRef} type="text" placeholder="Endereço de Destino" required />
        <button type="submit">Mostrar Rota no Mapa</button>
      </form>
      {iframeUrl && (
        <iframe
          title="Google Maps Route"
          src={iframeUrl}
          style={{ width: "100%", height: 300, marginTop: 16 }}
          allowFullScreen
        />
      )}
    </div>
  );
}
import React from "react";
import TrafficLight from "./TrafficLight";

export default function RideHistory({ history }) {
  return (
    <div>
      <h3>Histórico de Corridas</h3>
      <table>
        <thead>
          <tr>
            <th>Data/Hora</th>
            <th>Valor</th>
            <th>Km</th>
            <th>Min</th>
            <th>R$/km</th>
            <th>R$/min</th>
            <th>Semáforo</th>
          </tr>
        </thead>
        <tbody>
          {history.map((item, i) => (
            <tr key={i}>
              <td>{new Date(item.date).toLocaleString()}</td>
              <td>R$ {item.value.toFixed(2)}</td>
              <td>{item.km}</td>
              <td>{item.min}</td>
              <td>R$ {item.valuePerKm.toFixed(2)}</td>
              <td>R$ {item.valuePerMin.toFixed(2)}</td>
              <td><TrafficLight result={item.result} /></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}